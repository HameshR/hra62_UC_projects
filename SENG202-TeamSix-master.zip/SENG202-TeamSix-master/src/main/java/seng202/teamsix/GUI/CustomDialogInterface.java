package seng202.teamsix.GUI;

import javafx.stage.Stage;

public interface CustomDialogInterface {
    public void preSet(Stage stage);
}
