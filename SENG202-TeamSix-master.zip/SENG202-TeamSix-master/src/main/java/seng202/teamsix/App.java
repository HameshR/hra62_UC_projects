package seng202.teamsix;

import seng202.teamsix.GUI.*;

/**
 * Name: App.java
 *
 * Contributors:
         * Connor Macdonald
         * Taran Jennison
         * Hamesh Ravji
         * George Stephenson
         * Anzac Morel
         * Andrew Clifford
         * Rchi Lugtu
 *
 * Description: Where we start the application.
 * Date: August - September, 2019
 */
public class App {
    public static void main( String[] args )
    {
        FoodByteApplication.main(args);
    }
}